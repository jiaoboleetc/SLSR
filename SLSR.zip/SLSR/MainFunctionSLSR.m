
fullpath                                                                   = mfilename( 'fullpath' ); 

[ path, name ]                                                             = fileparts( fullpath );

original_graph_address                                                     = strcat( path, '\com-youtubeungraph.txt' );
    
original_graph                                                             = load( original_graph_address );

[ original_graph, new2old_indicator ]                                      = RemovingMultipleAndSelfloopEdges( original_graph );
[ original_graph, n, m, new2old_indicator ]                                = NodePairTransformation( original_graph );
[ node_degree, nei_pointer, nei_node_sets ]                                = GetNeiNodeSets( original_graph, n, m );

sampling_rate                                                              = 0.05;

sampled_graph                                                              = SLSR( node_degree, nei_pointer, nei_node_sets, n, m, sampling_rate );

write_path                                                                 = strcat( path, '\sampled-com-youtubeungraph.txt' );

fid_w                                                                      = fopen( write_path, 'w' );
fprintf( fid_w, '%d %d \r\n', sampled_graph' );
fclose( fid_w );