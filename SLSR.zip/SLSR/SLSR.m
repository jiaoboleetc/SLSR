function [ sampled_graph ] = SLSR( node_degree, nei_pointer, nei_node_sets, n, m, sampling_rate )
%Sampling unknown large networks restricted by low sampling rates
    %Random node sampling
    %AD evaluation
    sampling_rate_random_node_sampling                                     = 0.35;    
    sampled_node_set                                                       = randperm( n, round( n*sampling_rate_random_node_sampling ) );
    sampled_average_degree                                                 = mean( node_degree( sampled_node_set ) );
    sampled_max_degree                                                     = max( node_degree( sampled_node_set ) );
    average_degree                                                         = sampled_average_degree;
    %DT evaluation
    core_degree_set                                                        = zeros( 1, m );
    core_degree_pointer                                                    = 0;
    for deg = 1: 1: sampled_max_degree
        cur_deg_node_set                                                   = sampled_node_set( find( node_degree( sampled_node_set ) == deg ) );
        start_pointer                                                      = core_degree_pointer;
        for nod_id = 1: 1: length( cur_deg_node_set )
            node                                                           = cur_deg_node_set( nod_id );
            node_neighbor_degree_set                                       = node_degree( nei_node_sets( [ nei_pointer( node ): 1: nei_pointer( node ) + node_degree( node ) - 1 ] ) );
            current_core_degree_set                                        = node_neighbor_degree_set( find( node_neighbor_degree_set > deg ) );
            added_number                                                   = length( current_core_degree_set );
            core_degree_set( core_degree_pointer + [ 1: added_number ] )   = current_core_degree_set;
            core_degree_pointer                                            = core_degree_pointer + added_number;
        end
        total_added_number                                                 = core_degree_pointer - start_pointer;
        total_deleted_number                                               = length( find( core_degree_set( [ 1: start_pointer ] ) == deg ) );
        if total_added_number <= total_deleted_number
            break;
        end
    end 
    cor_degree_threshold                                                   = deg - 1;   
    %Initialization
    bart                                                                   = 0.7;
    FIFO_queue                                                             = zeros( 1, n );
    start_pointer                                                          = 1;
    end_pointer                                                            = 0;
    node_pair                                                              = zeros( m, 2 );
    node_pair_pointer                                                      = 0;    
    desired_node_number                                                    = round( n*sampling_rate );
    b_stop_adding_node                                                     = false;
    per_node_pointer                                                       = zeros( desired_node_number + 1000, 2 );
    per_neighbor_pointer                                                   = zeros( 1, m );
    %Periphey sampling
    per_node_set                                                           = find( node_degree <= cor_degree_threshold );
    while end_pointer <= desired_node_number | start_pointer <= end_pointer
        if start_pointer > end_pointer
            no_travel_per_node_set                                         = setdiff( per_node_set, FIFO_queue( [ 1: end_pointer ] ) );
            seed_node                                                      = no_travel_per_node_set( randi( length( no_travel_per_node_set ), 1, 1 ) );
            end_pointer                                                    = end_pointer + 1;
            FIFO_queue( end_pointer )                                      = seed_node;
        end
        cur_node                                                           = FIFO_queue( start_pointer );       
        cur_node_neighbors                                                 = nei_node_sets( [ nei_pointer( cur_node ): 1: nei_pointer( cur_node ) + node_degree( cur_node ) - 1 ] );
        cur_node_CorNeighbors                                              = cur_node_neighbors( find( node_degree( cur_node_neighbors ) > cor_degree_threshold ) );
        cur_node_PerNeighbors                                              = setdiff( cur_node_neighbors, cur_node_CorNeighbors );
        cur_node_NoTraval_PerNeighbors                                     = setdiff( cur_node_PerNeighbors, FIFO_queue( [ 1: end_pointer ] ) );
        cur_node_ConnectionNeighbors                                       = intersect( cur_node_PerNeighbors, FIFO_queue( [ 1: start_pointer - 1 ] ) );        
        if b_stop_adding_node == false
            forward_burning_number                                         = random( 'Geometric', 1 - bart, 1, 1 );
            len                                                            = length( cur_node_NoTraval_PerNeighbors );
            if len >= forward_burning_number
                adding_neighbors                                           = cur_node_NoTraval_PerNeighbors( randperm( len, forward_burning_number ) );          
                len                                                        = forward_burning_number;
            else
                adding_neighbors                                           = cur_node_NoTraval_PerNeighbors;
            end
            FIFO_queue( end_pointer + [ 1: len ] )                         = adding_neighbors;
            end_pointer                                                    = end_pointer + len;
        end
        len                                                                = length( cur_node_ConnectionNeighbors );
        node_pair( node_pair_pointer + [ 1: len ], : )                     = [ cur_node*ones( 1, len ); cur_node_ConnectionNeighbors ]';
        node_pair_pointer                                                  = node_pair_pointer + len;
        if end_pointer >= desired_node_number
            b_stop_adding_node                                             = true;
        end
        %Recording
        per_node_pointer( start_pointer + 1, : )                           = [ cur_node, per_node_pointer( start_pointer, 2 ) + length( cur_node_CorNeighbors ) ];
        per_neighbor_pointer( [ per_node_pointer( start_pointer, 2 ) + 1: per_node_pointer( start_pointer + 1, 2 ) ] ) = cur_node_CorNeighbors;
        start_pointer                                                      = start_pointer + 1;
    end
    %Adjusting top_percentage
    start_id                                                               = 1;
    end_id                                                                 = 100;
    AD_minimum_distance                                                    = 1000;
    while end_id - start_id > 1
        middle_id                                                          = round( ( start_id + end_id )/2 );
        top_percentage                                                     = middle_id/100;
        edge_number                                                        = node_pair_pointer;
        core_node_set                                                      = zeros( 1, 0 );
        for node_id = 1: 1: end_pointer
            cur_node                                                       = per_node_pointer( node_id + 1, 1 );
            cur_node_CorNeighbors                                          = per_neighbor_pointer( [ per_node_pointer( node_id, 2 ) + 1: per_node_pointer( node_id + 1, 2 ) ] );
            core_burning_number                                            = round( length( cur_node_CorNeighbors )*top_percentage );
            [ sorted_degree, sorted_position ]                             = sort( node_degree( cur_node_CorNeighbors ), 'descend' );
            adding_core_nodes                                              = cur_node_CorNeighbors( sorted_position( [ 1: core_burning_number ] ) );
            core_node_set                                                  = union( core_node_set, adding_core_nodes );
            edge_number                                                    = edge_number + core_burning_number;
        end
        core_node_number                                                   = length( core_node_set );
        node_number                                                        = end_pointer + core_node_number;
        for id = 1: 1: core_node_number - 1
            cur_core_node                                                  = core_node_set( id );
            cur_core_node_neighbors                                        = nei_node_sets( [ nei_pointer( cur_core_node ): 1: nei_pointer( cur_core_node ) + node_degree( cur_core_node ) - 1 ] );
            core_neighbors                                                 = intersect( cur_core_node_neighbors, core_node_set( [ id + 1: core_node_number ] ) );
            core_neighbor_number                                           = length( core_neighbors );
            edge_number                                                    = edge_number + core_neighbor_number;
        end
        sampled_average_degree                                             = 2*edge_number/node_number;
        if sampled_average_degree >= average_degree
            end_id                                                         = middle_id;
        else
            start_id                                                       = middle_id;
        end
        if abs( sampled_average_degree - average_degree ) < AD_minimum_distance
            optimum_top_percentage                                         = top_percentage;
            AD_minimum_distance                                            = abs( sampled_average_degree - average_degree );
        end
    end
    top_percentage                                                         = optimum_top_percentage;    
    %Outputing
    core_node_set                                                          = zeros( 1, 0 );
    for node_id = 1: 1: end_pointer
        cur_node                                                           = per_node_pointer( node_id + 1, 1 );
        cur_node_CorNeighbors                                              = per_neighbor_pointer( [ per_node_pointer( node_id, 2 ) + 1: per_node_pointer( node_id + 1, 2 ) ] );
        len                                                                = length( cur_node_CorNeighbors );
        core_burning_number                                                = round( len*top_percentage );
        [ sorted_degree, sorted_position ]                                 = sort( node_degree( cur_node_CorNeighbors ), 'descend' );
        adding_core_nodes                                                  = cur_node_CorNeighbors( sorted_position( [ 1: core_burning_number ] ) );
        core_node_set                                                      = union( core_node_set, adding_core_nodes );
        node_pair( node_pair_pointer + [ 1: core_burning_number ], : )     = [ cur_node*ones( 1, core_burning_number ); adding_core_nodes ]';
        node_pair_pointer                                                  = node_pair_pointer + core_burning_number;
    end
    %Connecting core nodes
    core_node_number                                                       = length( core_node_set );
    for id = 1: 1: core_node_number - 1
        cur_core_node                                                      = core_node_set( id );
        cur_core_node_neighbors                                            = nei_node_sets( [ nei_pointer( cur_core_node ): 1: nei_pointer( cur_core_node ) + node_degree( cur_core_node ) - 1 ] );
        core_neighbors                                                     = intersect( cur_core_node_neighbors, core_node_set( [ id + 1: core_node_number ] ) );
        core_neighbor_number                                               = length( core_neighbors );
        node_pair( node_pair_pointer + [ 1: core_neighbor_number ], : )    = [ cur_core_node*ones( 1, core_neighbor_number ); core_neighbors ]';
        node_pair_pointer                                                  = node_pair_pointer + core_neighbor_number;
    end
    sampled_graph                                                          = node_pair( [ 1: node_pair_pointer ], : );
end